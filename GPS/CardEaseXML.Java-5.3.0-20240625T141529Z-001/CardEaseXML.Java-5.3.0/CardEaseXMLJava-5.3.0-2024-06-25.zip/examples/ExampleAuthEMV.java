import java.io.IOException;

import com.creditcall.CardEaseXMLCommunicationException;
import com.creditcall.CardEaseXMLRequestException;
import com.creditcall.CardEaseXMLResponseException;
import com.creditcall.Client;
import com.creditcall.ICCTag;
import com.creditcall.ICCTagValueType;
import com.creditcall.Request;
import com.creditcall.RequestType;
import com.creditcall.Response;

/**
 * Example authorisation with EMV tags.
 * 
 * @author CreditCall Ltd
 * 
 */
public class ExampleAuthEMV {

	/**
	 * Example authorisation with EMV tags.
	 * 
	 * @param args
	 *            TerminalID and TransactionKey
	 * @throws IOException
	 *             on read error
	 */
	public static final void main(final String[] args) throws IOException {

		if (args.length != 2) {
			System.err.println("Usage: " + ExampleAuthEMV.class.getName() + "TerminalID TransactionKey");
			System.err.println();
			System.err.println("The TerminalID and TransactionKey are provided at registration:");
			System.err.println();
			System.err.println("        https://testwebmis.creditcall.com");
			System.err.println();
			System.err.println("Press Enter to continue . . .");
			System.in.read();
			System.exit(1);
		}

		// Setup the request
		Request request = new Request();

		request.setSoftwareName("SoftwareName");
		request.setSoftwareVersion("SoftwareVersion");
		request.setTerminalID(args[0]);
		request.setTransactionKey(args[1]);

		// Setup the request detail
		request.setRequestType(RequestType.Auth);
		request.setAmount("123");
		request.addICCTag(new ICCTag("0x57", "5413330089000013D0712201087490938F"));
		request.addICCTag(new ICCTag("0x5a", "5413330089000013"));
		request.addICCTag(new ICCTag("0x5f24", "071231"));
		request.addICCTag(new ICCTag("0x5f34", "00"));
		request.addICCTag(new ICCTag("0x9f02", "000000000123"));
		request.addICCTag(new ICCTag("0x9f03", "000000000000"));
		request.addICCTag(new ICCTag("0x9f26", "095BDFF410C27326"));
		request.addICCTag(new ICCTag("0x82", "1800"));
		request.addICCTag(new ICCTag("0x9f36", "0003"));
		request.addICCTag(new ICCTag("0x9f37", "28BB7FE5"));
		request.addICCTag(new ICCTag("0x95", "800000E000"));
		request.addICCTag(new ICCTag("0x9c", "00"));
		request.addICCTag(new ICCTag("0x9f10", "020000000000"));
		request.addICCTag(new ICCTag("0x9f06", "A0000000041010"));
		request.addICCTag(new ICCTag("0x9f09", "0002"));
		request.addICCTag(new ICCTag("0x9f27", "80"));
		request.addICCTag(new ICCTag("0x9f34", "410302"));
		request.addICCTag(new ICCTag("0x9f35", "24"));
		request.addICCTag(new ICCTag("0x9b", "6800"));
		request.addICCTag(new ICCTag("0x4f", "A0000000041010"));
		request.addICCTag(new ICCTag("0x9f08", "0002"));
		request.addICCTag(new ICCTag("0x9f07", "FF00"));
		request.addICCTag(new ICCTag("0x5f28", "0056"));
		request.addICCTag(new ICCTag("0x9f0d", "F040642000"));
		request.addICCTag(new ICCTag("0x9f0e", "0010880000"));
		request.addICCTag(new ICCTag("0x9f0f", "F0E064F800"));
		request.addICCTag(new ICCTag("0x9f33", "6098C8"));
		request.addICCTag(new ICCTag("0x9a", "060424"));
		request.addICCTag(new ICCTag("0x5f20", ICCTagValueType.String, "REQ01 MC"));

		System.out.println(request);

		// Setup the client
		Client client = new Client();
		client.setRequest(request);

		try {
			client.addServerURL("https://test.cardeasexml.com/generic.cex", 45000);

			// Process the request
			client.processRequest();

		} catch (final CardEaseXMLCommunicationException e) {
			// There is something wrong with communication
			e.printStackTrace();
			System.exit(1);

		} catch (final CardEaseXMLRequestException e) {
			// There is something wrong with the request
			e.printStackTrace();
			System.exit(1);

		} catch (final CardEaseXMLResponseException e) {
			// There is something wrong with the response
			e.printStackTrace();
			System.exit(1);
		}

		// Get the response
		Response response = client.getResponse();
		System.out.println(response);
	}
}
