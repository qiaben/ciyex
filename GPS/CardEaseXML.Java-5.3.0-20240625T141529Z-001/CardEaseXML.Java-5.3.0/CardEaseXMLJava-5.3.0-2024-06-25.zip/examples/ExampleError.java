import java.io.IOException;
import java.util.List;

import com.creditcall.CardEaseXMLCommunicationException;
import com.creditcall.CardEaseXMLRequestException;
import com.creditcall.CardEaseXMLResponseException;
import com.creditcall.Client;
import com.creditcall.Error;
import com.creditcall.Request;
import com.creditcall.RequestType;
import com.creditcall.Response;

/**
 * Example authorisation with error.
 * 
 * @author CreditCall Ltd
 * 
 */
public class ExampleError {

	/**
	 * Example authorisation with error.
	 * 
	 * @param args
	 *            TerminalID and TransactionKey
	 * @throws IOException
	 *             on read error
	 */
	public static final void main(final String[] args) throws IOException {

		if (args.length != 2) {
			System.err.println("Usage: " + ExampleError.class.getName() + "TerminalID TransactionKey");
			System.err.println();
			System.err.println("The TerminalID and TransactionKey are provided at registration:");
			System.err.println();
			System.err.println("        https://testwebmis.creditcall.com");
			System.err.println();
			System.err.println("Press Enter to continue . . .");
			System.in.read();
			System.exit(1);
		}

		// Setup the request
		Request request = new Request();

		request.setSoftwareName("SoftwareName");
		request.setSoftwareVersion("SoftwareVersion");
		request.setTerminalID(args[0]);
		request.setTransactionKey(args[1]);

		// Setup the request detail
		request.setRequestType(RequestType.Auth);
		request.setAmount("123");
		request.setTrack2(";this is a bad track2?");

		System.out.println(request);

		// Setup the client
		Client client = new Client();
		client.setRequest(request);

		try {
			client.addServerURL("https://test.cardeasexml.com/generic.cex", 45000);

			// Process the request
			client.processRequest();

		} catch (final CardEaseXMLCommunicationException e) {
			// There is something wrong with communication
			e.printStackTrace();
			System.exit(1);

		} catch (final CardEaseXMLRequestException e) {
			// There is something wrong with the request
			e.printStackTrace();
			System.exit(1);

		} catch (final CardEaseXMLResponseException e) {
			// There is something wrong with the response
			e.printStackTrace();
			System.exit(1);
		}

		// Get the response
		Response response = client.getResponse();
		System.out.println(response);

		List<Error> errors = response.getErrors();
		if (errors != null) {
			for (Error error : response.getErrors()) {
				System.out.println(error);
			}
		}
	}
}
