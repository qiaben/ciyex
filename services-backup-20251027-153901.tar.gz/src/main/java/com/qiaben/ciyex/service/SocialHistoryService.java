package com.qiaben.ciyex.service;

import com.qiaben.ciyex.dto.SocialHistoryDto;
import com.qiaben.ciyex.dto.SocialHistoryEntryDto;
import com.qiaben.ciyex.entity.SocialHistory;
import com.qiaben.ciyex.entity.SocialHistoryEntry;
import com.qiaben.ciyex.repository.SocialHistoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class SocialHistoryService {

    private final SocialHistoryRepository repo;
    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    // CREATE (container + entries)
    public SocialHistoryDto create(Long orgId, Long patientId, Long encounterId, SocialHistoryDto dto) {
        SocialHistory e = new SocialHistory();
        e.setPatientId(patientId);
        e.setEncounterId(encounterId);
        applyEntries(e, dto.getEntries());
        e = repo.save(e);
        return toDto(e);
    }

    // READ one container (first if multiple)
    public SocialHistoryDto getOne(Long orgId, Long patientId, Long encounterId) {
        List<SocialHistory> list = repo.findByPatientIdAndEncounterId(patientId, encounterId);
        SocialHistory e = list.isEmpty() ? null : list.get(0);
        if (e == null) throw new IllegalArgumentException("Social History not found");
        return toDto(e);
    }

    // READ by id
    public SocialHistoryDto getById(Long orgId, Long patientId, Long encounterId, Long id) {
        SocialHistory e = repo.findByPatientIdAndEncounterIdAndId(patientId, encounterId, id)
                .orElseThrow(() -> new IllegalArgumentException("Social History not found"));
        return toDto(e);
    }

    // UPDATE container (blocked if signed)
    public SocialHistoryDto update(Long orgId, Long patientId, Long encounterId, Long id, SocialHistoryDto dto) {
        SocialHistory e = repo.findByPatientIdAndEncounterIdAndId(patientId, encounterId, id)
                .orElseThrow(() -> new IllegalArgumentException("Social History not found"));
        if (Boolean.TRUE.equals(e.getESigned())) {
            throw new IllegalStateException("Signed Social History is read-only.");
        }
        applyEntries(e, dto.getEntries());
        e = repo.save(e);
        return toDto(e);
    }

    // DELETE container (blocked if signed)
    public void delete(Long orgId, Long patientId, Long encounterId, Long id) {
        SocialHistory e = repo.findByPatientIdAndEncounterIdAndId(patientId, encounterId, id)
                .orElseThrow(() -> new IllegalArgumentException("Social History not found"));
        if (Boolean.TRUE.equals(e.getESigned())) {
            throw new IllegalStateException("Signed Social History cannot be deleted.");
        }
        repo.delete(e);
    }

    // eSIGN (idempotent)
    public SocialHistoryDto eSign(Long orgId, Long patientId, Long encounterId, Long id, String signedBy) {
        SocialHistory e = repo.findByPatientIdAndEncounterIdAndId(patientId, encounterId, id)
                .orElseThrow(() -> new IllegalArgumentException("Social History not found"));
        if (Boolean.TRUE.equals(e.getESigned())) return toDto(e);
        e.setESigned(true);
        e.setSignedAt(OffsetDateTime.now(ZoneOffset.UTC));
        e.setSignedBy(StringUtils.hasText(signedBy) ? signedBy : "system");
        e = repo.save(e);
        return toDto(e);
    }

    // PRINT (PDF) — also stamps printedAt
    public byte[] renderPdf(Long orgId, Long patientId, Long encounterId, Long id) {
        SocialHistory e = repo.findByPatientIdAndEncounterIdAndId(patientId, encounterId, id)
                .orElseThrow(() -> new IllegalArgumentException("Social History not found"));
        e.setPrintedAt(OffsetDateTime.now(ZoneOffset.UTC));
        repo.save(e);

        try (PDDocument doc = new PDDocument(); ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            PDPage page = new PDPage(PDRectangle.LETTER);
            doc.addPage(page);

            try (PDPageContentStream cs = new PDPageContentStream(doc, page)) {
                float x = 64, y = 740;

                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA_BOLD, 18);
                cs.newLineAtOffset(x, y);
                cs.showText("Social History");
                cs.endText();

                y -= 26;
                draw(cs, x, y, "Patient ID:", String.valueOf(patientId)); y -= 16;
                draw(cs, x, y, "Encounter ID:", String.valueOf(encounterId)); y -= 16;
                draw(cs, x, y, "Record ID:", String.valueOf(id)); y -= 22;

                if (e.getEntries() != null && !e.getEntries().isEmpty()) {
                    for (int i = 0; i < e.getEntries().size(); i++) {
                        SocialHistoryEntry it = e.getEntries().get(i);
                        cs.beginText();
                        cs.setFont(PDType1Font.HELVETICA_BOLD, 12);
                        cs.newLineAtOffset(x, y);
                        cs.showText((i + 1) + ". " + (it.getCategory() != null ? it.getCategory() : "—"));
                        cs.endText();
                        y -= 14;

                        if (StringUtils.hasText(it.getValue())) { draw(cs, x + 16, y, "Value:", it.getValue()); y -= 14; }
                        if (StringUtils.hasText(it.getDetails())) {
                            draw(cs, x + 16, y, "Details:", ""); y -= 14;
                            for (String ln : it.getDetails().split("\\R")) {
                                cs.beginText(); cs.setFont(PDType1Font.HELVETICA, 12); cs.newLineAtOffset(x + 16, y);
                                cs.showText(ln); cs.endText();
                                y -= 14;
                            }
                        }
                        y -= 8;
                    }
                } else {
                    draw(cs, x, y, "Entries:", "(none)"); y -= 16;
                }

                y -= 8;
                draw(cs, x, y, "eSigned:", Boolean.TRUE.equals(e.getESigned()) ? "Yes" : "No"); y -= 16;
                if (e.getSignedAt() != null) { draw(cs, x, y, "Signed At:", e.getSignedAt().toString()); y -= 16; }
                if (StringUtils.hasText(e.getSignedBy())) { draw(cs, x, y, "Signed By:", e.getSignedBy()); y -= 16; }
            }

            doc.save(baos);
            return baos.toByteArray();
        } catch (IOException ex) {
            throw new RuntimeException("Failed to generate Social History PDF", ex);
        }
    }

    // ---- helpers ----
    private static void draw(PDPageContentStream cs, float x, float y, String label, String value) throws IOException {
        cs.beginText(); cs.setFont(PDType1Font.HELVETICA_BOLD, 12); cs.newLineAtOffset(x, y); cs.showText(label); cs.endText();
        cs.beginText(); cs.setFont(PDType1Font.HELVETICA, 12); cs.newLineAtOffset(x + 140, y); cs.showText(value != null ? value : "-"); cs.endText();
    }

    private SocialHistoryDto toDto(SocialHistory e) {
        SocialHistoryDto d = new SocialHistoryDto();
        d.setId(e.getId());
        d.setExternalId(e.getExternalId());
        d.setPatientId(e.getPatientId());
        d.setEncounterId(e.getEncounterId());

        List<SocialHistoryEntryDto> list = new ArrayList<>();
        for (SocialHistoryEntry it : e.getEntries()) {
            SocialHistoryEntryDto ed = new SocialHistoryEntryDto();
            ed.setId(it.getId());
            ed.setCategory(it.getCategory());
            ed.setDetails(it.getDetails());
            ed.setValue(it.getValue());
            list.add(ed);
        }
        d.setEntries(list);

        d.setESigned(e.getESigned());
        d.setSignedAt(e.getSignedAt());
        d.setSignedBy(e.getSignedBy());
        d.setPrintedAt(e.getPrintedAt());

        SocialHistoryDto.Audit a = new SocialHistoryDto.Audit();
        if (e.getCreatedAt() != null) a.setCreatedDate(DAY.format(e.getCreatedAt().atZone(ZoneId.systemDefault())));
        if (e.getUpdatedAt() != null) a.setLastModifiedDate(DAY.format(e.getUpdatedAt().atZone(ZoneId.systemDefault())));
        d.setAudit(a);
        return d;
    }

    private void applyEntries(SocialHistory e, List<SocialHistoryEntryDto> dtos) {
        e.getEntries().clear();
        if (dtos == null) return;
        for (SocialHistoryEntryDto d : dtos) {
            SocialHistoryEntry it = new SocialHistoryEntry();
            it.setCategory(d.getCategory());
            it.setDetails(d.getDetails());
            it.setValue(d.getValue());
            it.setSocialHistory(e);
            e.getEntries().add(it);
        }
    }
}
