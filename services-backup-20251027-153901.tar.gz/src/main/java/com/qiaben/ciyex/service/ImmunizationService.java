package com.qiaben.ciyex.service;

import com.qiaben.ciyex.dto.ApiResponse;
import com.qiaben.ciyex.dto.ImmunizationDto;
import com.qiaben.ciyex.entity.Immunization;
import com.qiaben.ciyex.repository.ImmunizationRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ImmunizationService {

    private final ImmunizationRepository repository;

    public ImmunizationService(ImmunizationRepository repository) {
        this.repository = repository;
    }

    // ---------- Patient-level ----------

    @Transactional
    public ImmunizationDto create(ImmunizationDto dto) {

        ImmunizationDto.ImmunizationItem item = dto.getImmunizations().get(0);
        Immunization entity = mapToEntity(dto.getPatientId(), item);

        entity = repository.save(entity);
        item.setId(entity.getId());
        item.setExternalId(entity.getExternalId());
        item.setPatientId(entity.getPatientId());

        return buildDtoFromEntity(entity);
    }

    @Transactional(readOnly = true)
    public ImmunizationDto getByPatientId(Long patientId) {

        List<Immunization> entities = repository.findByPatientId(patientId);
        return buildDtoFromEntities(patientId, entities);
    }

    @Transactional
    public ImmunizationDto updateByPatientId(Long patientId, ImmunizationDto dto) {


        if (dto.getImmunizations() == null || dto.getImmunizations().isEmpty()) {
            throw new IllegalArgumentException("No immunization data provided");
        }

        ImmunizationDto.ImmunizationItem patch = dto.getImmunizations().get(0);

        Immunization entity = repository.findOneByIdAndPatientId(patch.getId(), patientId);

        applyPatch(entity, patch);
        repository.save(entity);
        return buildDtoFromEntity(entity);
    }


    @Transactional
    public void deleteByPatientId(Long patientId) {
        List<Immunization> entities = repository.findByPatientId(patientId);
        repository.deleteAll(entities);
    }

    // ---------- Item-level ----------

    @Transactional(readOnly = true)
    public ImmunizationDto.ImmunizationItem getItem(Long patientId, Long immunizationId) {
        Immunization entity = repository.findOneByIdAndPatientId(immunizationId, patientId);
        return mapToItem(entity);
    }

    @Transactional
    public ImmunizationDto.ImmunizationItem updateItem(Long patientId, Long immunizationId, ImmunizationDto.ImmunizationItem patch) {

        Immunization entity = repository.findOneByIdAndPatientId(immunizationId, patientId);

        applyPatch(entity, patch);
        repository.save(entity);
        return mapToItem(entity);
    }

    @Transactional
    public void deleteItem(Long patientId, Long immunizationId) {
        Immunization entity = repository.findOneByIdAndPatientId(immunizationId, patientId);
        repository.delete(entity);
    }

    // ---------- Search All ----------

    @Transactional(readOnly = true)
    public ApiResponse<List<ImmunizationDto>> searchAll() {

        List<Immunization> entities = repository.findAll();

        var grouped = entities.stream()
                .collect(Collectors.groupingBy(Immunization::getPatientId));

        List<ImmunizationDto> result = grouped.entrySet().stream()
                .map(entry -> buildDtoFromEntities(entry.getKey(), entry.getValue()))
                .collect(Collectors.toList());

        return ApiResponse.<List<ImmunizationDto>>builder()
                .success(true)
                .message("Immunizations retrieved successfully")
                .data(result)
                .build();
    }

    // ---------- Helpers ----------

    private Immunization mapToEntity(Long patientId, ImmunizationDto.ImmunizationItem item) {
        return Immunization.builder()
                .patientId(patientId)
                .externalId(item.getExternalId())
                .cvxCode(item.getCvxCode())
                .dateTimeAdministered(item.getDateTimeAdministered())
                .amountAdministered(item.getAmountAdministered())
                .expirationDate(item.getExpirationDate())
                .manufacturer(item.getManufacturer())
                .lotNumber(item.getLotNumber())
                .administratorName(item.getAdministratorName())
                .administratorTitle(item.getAdministratorTitle())
                .dateVisGiven(item.getDateVisGiven())
                .dateVisStatement(item.getDateVisStatement())
                .route(item.getRoute())
                .administrationSite(item.getAdministrationSite())
                .notes(item.getNotes())
                .informationSource(item.getInformationSource())
                .completionStatus(item.getCompletionStatus())
                .substanceRefusalReason(item.getSubstanceRefusalReason())
                .reasonCode(item.getReasonCode())
                .orderingProvider(item.getOrderingProvider())
                .build();
    }

    private ImmunizationDto.ImmunizationItem mapToItem(Immunization entity) {
        ImmunizationDto.ImmunizationItem item = new ImmunizationDto.ImmunizationItem();
        item.setId(entity.getId());
        item.setExternalId(entity.getExternalId());
        item.setPatientId(entity.getPatientId());
        item.setCvxCode(entity.getCvxCode());
        item.setDateTimeAdministered(entity.getDateTimeAdministered());
        item.setAmountAdministered(entity.getAmountAdministered());
        item.setExpirationDate(entity.getExpirationDate());
        item.setManufacturer(entity.getManufacturer());
        item.setLotNumber(entity.getLotNumber());
        item.setAdministratorName(entity.getAdministratorName());
        item.setAdministratorTitle(entity.getAdministratorTitle());
        item.setDateVisGiven(entity.getDateVisGiven());
        item.setDateVisStatement(entity.getDateVisStatement());
        item.setRoute(entity.getRoute());
        item.setAdministrationSite(entity.getAdministrationSite());
        item.setNotes(entity.getNotes());
        item.setInformationSource(entity.getInformationSource());
        item.setCompletionStatus(entity.getCompletionStatus());
        item.setSubstanceRefusalReason(entity.getSubstanceRefusalReason());
        item.setReasonCode(entity.getReasonCode());
        item.setOrderingProvider(entity.getOrderingProvider());
        return item;
    }

    private void applyPatch(Immunization entity, ImmunizationDto.ImmunizationItem patch) {
        if (patch.getExternalId() != null) entity.setExternalId(patch.getExternalId());
        if (patch.getCvxCode() != null) entity.setCvxCode(patch.getCvxCode());
        if (patch.getDateTimeAdministered() != null) entity.setDateTimeAdministered(patch.getDateTimeAdministered());
        if (patch.getAmountAdministered() != null) entity.setAmountAdministered(patch.getAmountAdministered());
        if (patch.getExpirationDate() != null) entity.setExpirationDate(patch.getExpirationDate());
        if (patch.getManufacturer() != null) entity.setManufacturer(patch.getManufacturer());
        if (patch.getLotNumber() != null) entity.setLotNumber(patch.getLotNumber());
        if (patch.getAdministratorName() != null) entity.setAdministratorName(patch.getAdministratorName());
        if (patch.getAdministratorTitle() != null) entity.setAdministratorTitle(patch.getAdministratorTitle());
        if (patch.getDateVisGiven() != null) entity.setDateVisGiven(patch.getDateVisGiven());
        if (patch.getDateVisStatement() != null) entity.setDateVisStatement(patch.getDateVisStatement());
        if (patch.getRoute() != null) entity.setRoute(patch.getRoute());
        if (patch.getAdministrationSite() != null) entity.setAdministrationSite(patch.getAdministrationSite());
        if (patch.getNotes() != null) entity.setNotes(patch.getNotes());
        if (patch.getInformationSource() != null) entity.setInformationSource(patch.getInformationSource());
        if (patch.getCompletionStatus() != null) entity.setCompletionStatus(patch.getCompletionStatus());
        if (patch.getSubstanceRefusalReason() != null) entity.setSubstanceRefusalReason(patch.getSubstanceRefusalReason());
        if (patch.getReasonCode() != null) entity.setReasonCode(patch.getReasonCode());
        if (patch.getOrderingProvider() != null) entity.setOrderingProvider(patch.getOrderingProvider());
    }

    private ImmunizationDto buildDtoFromEntity(Immunization entity) {
        ImmunizationDto dto = new ImmunizationDto();
        dto.setPatientId(entity.getPatientId());

        dto.setImmunizations(List.of(mapToItem(entity)));
        return dto;
    }

    private ImmunizationDto buildDtoFromEntities(Long patientId, List<Immunization> entities) {
        ImmunizationDto dto = new ImmunizationDto();
        dto.setPatientId(patientId);

        if (!entities.isEmpty()) {
            Immunization latest = entities.get(entities.size() - 1);
        }

        dto.setImmunizations(entities.stream().map(this::mapToItem).collect(Collectors.toList()));
        return dto;
    }
}
